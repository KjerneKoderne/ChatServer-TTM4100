# ChatServer-TTM4100
TTM4100 group project, ChatServer with Client connections


Klienten vår skal kunne sende ut dei 5 forskjellige funksjonane login etterfulgt brukarnamn,
logout, msg etterfulgt meldinga, names for å hente ut liste med alle brukarane i chatterommet
og help for å hente hjelpetekst. Klienten vår etter programmet har starta skal koble seg på
ein bestemt server og alltid lytte etter brukarinput. Dette som skal sendast til serveren
som alltid ventar på førespurnadar frå klientane. Alt etter kva type førespurnad brukar kjem med
skal serveren sende ut eit svar som brukaren mottar, analyserar og printar til  
eigen konsoll.
